import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      LOAD_HIE_NODE:null,
      SET_HIE_NODE_LOAGDING:null,
  })

};
