import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      ADD_SEARCH_TAGLIST_CHANGED: null,
      REMOVE_SEARCH_TAGLIST_CHANGED: null,
      INTER_DATA_CHANGED: null,
      CLEAR_SEARCH_TAGLIST:null
  })

};
