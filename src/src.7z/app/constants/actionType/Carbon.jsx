import keyMirror from 'keymirror';

module.exports = keyMirror({
        GET_CARBON_DATA_LOADING: null,
        GET_CARBON_DATA_SUCCESS: null,
        GET_CARBON_DATA_ERROR: null
      }
  );
