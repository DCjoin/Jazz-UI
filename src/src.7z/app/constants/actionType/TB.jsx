import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      LOAD_TB:null,
      SAVE_TB:null,
  })
};
