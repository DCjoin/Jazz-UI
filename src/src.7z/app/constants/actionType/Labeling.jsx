import keyMirror from 'keymirror';

module.exports = {
  Action: keyMirror({
    HIERNODE_CHANGED: null,
    GET_ALL_INDUSTRIES_SUCCESS: null,
    GET_ALL_INDUSTRIES_ERROR: null,
    GET_ALL_ZONES_SUCCESS: null,
    GET_ALL_ZONES_ERROR: null,
    GET_ALL_LABELS_SUCCESS: null,
    GET_ALL_LABELS_ERROR: null,
    GET_ALL_CUSTOMER_LABELS_SUCCESS: null,
    GET_ALL_CUSTOMER_LABELS_ERROR: null,
    GET_BENCHMARK_DATA_SUCCESS: null,
    GET_BENCHMARK_DATA_ERROR: null,
    GET_HIERNODES_BY_ID_SUCCESS: null,
    GET_HIERNODES_BY_ID_ERROR: null
  })
};
