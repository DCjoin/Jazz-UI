import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      LOAD_TAG_NODE:null,
      LOAD_ALARM_TAG_NODE:null,
      SET_NODE_LOAGDING:null,
      SET_TAGSTATUS_TAG:null,
      SET_TAGSTATUS_ID:null,
      SET_TAGSTATUS_TAGLIST:null,
      SET_HIERARCHYID:null,
      SET_CURRENT_TAGLIST:null,
      RESET_TAGINFO: null,
      SET_CHECK_ALL_STATUS: null,
      CLEAR_ALARM_SEARCH_TAGLIST:null
  })

};
