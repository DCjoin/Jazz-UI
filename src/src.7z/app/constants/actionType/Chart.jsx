import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      REDRAW_CHART_IF_EXIST:null
  })

};
