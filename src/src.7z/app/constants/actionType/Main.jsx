import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      GET_ALL_UOMS_SUCCESS: null,
      GET_ALL_UOMS_ERROR: null,
      GET_ALL_COMMODITY_SUCCESS: null,
      GET_ALL_COMMODITY_ERROR: null
  })

};
