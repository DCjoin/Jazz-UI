import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      LOAD_DIM_NODE:null
  })

};
