import keyMirror from 'keymirror';

module.exports = {

    Action:keyMirror({
      LOADED_TBSETTING: null,
      LOAD_TBSETTING: null,
      SAVE_TBSETTING: null,
      CALCED_AVG_TAGDATA: null,
      LOAD_CALDETAIL:null,
      SET_HIERID:null,
      SET_TAGID:null,
      RESET_HIERID:null,
      RESET_TAGID:null,
      SET_YEAR:null,
      SET_CALDETAIL_LOAGDING:null,
  })
};
