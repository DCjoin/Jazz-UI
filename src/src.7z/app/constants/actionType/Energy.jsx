import keyMirror from 'keymirror';

module.exports = {
  Action:keyMirror({
    GET_ENERGY_DATA_LOADING: null,
    GET_ENERGY_DATA_SUCCESS: null,
    GET_ENERGY_DATA_ERROR: null,
    GET_COST_DATA_LOADING: null,
    GET_COST_DATA_SUCCESS: null,
    GET_COST_DATA_ERROR: null,
    EXPORT_CHART_ACTION_TYPE: null,
    GET_LABEL_DATA_LOADING: null,
    GET_LABEL_DATA_SUCCESS: null,
    GET_LABEL_DATA_ERROR: null,
    GET_RANK_DATA_LOADING: null,
    GET_RANK_DATA_SUCCESS: null,
    GET_RANK_DATA_ERROR: null,
    GET_RATIO_DATA_LOADING: null,
    GET_RATIO_DATA_SUCCESS: null,
    GET_RATIO_DATA_ERROR: null,
    INIT_MULTITIMESPAN_DATA: null,
    ADD_MULTITIMESPAN_DATA: null,
    REMOVE_MULTITIMESPAN_DATA: null,
    RELATIVE_TYPE_CHANGE: null,
    RELATIVE_VALUE_CHANGE: null,
    DATETIME_SELECTOR_CHANGE: null,
    CLEAR_MULTI_TIMESPAN: null,
    CONVERT_TEMP_TO_STABLE: null
  })
};
