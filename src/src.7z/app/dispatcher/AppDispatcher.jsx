import flux from 'flux';

let { Dispatcher } = flux;

module.exports = new Dispatcher();
